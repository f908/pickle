module.exports ={
    name:"help",
    code:`$channelSendMessage[$channelID;pickle slowko, pickle test, pickle help, pickle 2137, pickle かわいい;false]
$channelSendMessage[$channelID;Użycie CPU: $cpu% Użycie RAM: $ramMB;false]`
    }